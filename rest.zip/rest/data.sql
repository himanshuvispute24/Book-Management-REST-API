CREATE TABLE author (
    'id' INT AUTO_INCREMENT,  -- Auto-incrementing primary key
    'name' VARCHAR(100) NOT NULL
);


CREATE TABLE 'category' (
    'id' INT AUTO_INCREMENT,
    'cat_name' VARCHAR(100) NOT NULL
);

CREATE TABLE 'book' (
    'id' AUTO_INCREMENT PRIMARY KEY,
    'book_name' VARCHAR(100) NOT NULL,
    'book_description' TEXT NOT NULL,
    'author_id' INTEGER NOT NULL,
    FOREIGN KEY ('author_id') REFERENCES 'author'('id') ON DELETE CASCADE
);

CREATE TABLE 'book_categories' (
    'book_id' INTEGER NOT NULL,
    'category_id' INTEGER NOT NULL,
    PRIMARY KEY ('book_id','category_id'),
    FOREIGN KEY ('book_id') REFERENCES 'book'('id') ON DELETE CASCADE,
    FOREIGN KEY ('category_id') REFERENCES 'category'('id') ON DELETE CASCADE
);